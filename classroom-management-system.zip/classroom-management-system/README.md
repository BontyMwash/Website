# Classroom Management system 

A Pen created on CodePen.

Original URL: [https://codepen.io/Gorgeous-Smasher/pen/EaxRvRb](https://codepen.io/Gorgeous-Smasher/pen/EaxRvRb).

